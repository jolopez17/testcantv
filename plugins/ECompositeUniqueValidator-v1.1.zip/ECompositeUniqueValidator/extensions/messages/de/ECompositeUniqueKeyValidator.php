<?php
return array(
	'{attributes} with "{value}" already exists.'=>'{attributes} mit "{value}" existiert bereits.',
);
?>